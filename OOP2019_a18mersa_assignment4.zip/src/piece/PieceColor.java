package piece;

public enum PieceColor {
	BLACK, WHITE; 
}
